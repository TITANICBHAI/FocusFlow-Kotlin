FocusFlow import/export related files (flat bundle)

All project files are stored at the root of this ZIP. Filenames use prefixes to avoid collisions and make file roles clear.

Flattened filename -> original project-relative path
app-tabs__settings.tsx -> artifacts/focusflow/app/(tabs)/settings.tsx
app__import-confirm.tsx -> artifacts/focusflow/app/import-confirm.tsx
app__user-profile.tsx -> artifacts/focusflow/app/user-profile.tsx
services__backupService.ts -> artifacts/focusflow/src/services/backupService.ts
services__pendingBackupImport.ts -> artifacts/focusflow/src/services/pendingBackupImport.ts
app__root-layout.tsx -> artifacts/focusflow/app/_layout.tsx
native__NativeFilePickerModule.ts -> artifacts/focusflow/src/native-modules/NativeFilePickerModule.ts
android__NativeFilePickerModule.kt -> artifacts/focusflow/android-native/app/src/main/java/com/tbtechs/focusflow/modules/NativeFilePickerModule.kt
android__FocusDayPackage.kt -> artifacts/focusflow/android-native/app/src/main/java/com/tbtechs/focusflow/modules/FocusDayPackage.kt
plugin__withFocusDayAndroid.js -> artifacts/focusflow/plugins/withFocusDayAndroid.js
android__manifest_additions.xml -> artifacts/focusflow/android-native/manifest_additions.xml
android__install.sh -> artifacts/focusflow/android-native/install.sh
config__app.json -> artifacts/focusflow/app.json
test__backupService.test.ts -> artifacts/focusflow/tests/unit/backupService.test.ts
test__pendingBackupImport.test.ts -> artifacts/focusflow/tests/unit/pendingBackupImport.test.ts
docs__FOCUSFLOW_FEATURES_PLAN_TRACKING.md -> artifacts/focusflow/FOCUSFLOW_FEATURES_PLAN_TRACKING.md
docs__FOCUSFLOW_FEATURES_PLAN_1788805485351.md -> artifacts/focusflow/FOCUSFLOW_FEATURES_PLAN_1788805485351.md
tool__focusflow-backup-builder_1791092998409.html -> attached_assets/focusflow-backup-builder_1791092998409.html
